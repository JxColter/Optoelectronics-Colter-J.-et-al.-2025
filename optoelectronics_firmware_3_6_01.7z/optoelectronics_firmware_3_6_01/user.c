/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
#include <xc.h>
#elif defined(__C30__)
#if defined(__PIC24E__)
#include <p24Exxxx.h>
#elif defined (__PIC24F__)||defined (__PIC24FK__)
#include <p24Fxxxx.h>
#elif defined(__PIC24H__)
#include <p24Hxxxx.h>
#endif
#endif

#include <stdint.h>          /* For uint32_t definition */
#include <stdbool.h>         /* For true/false definition */
#include <libpic30.h>

#include "user.h"            /* variables/params used by user.c */
#include "system.h"
#include "global.h"
#include "interrupts.h"

/******************************************************************************/
/* User Initialization Functions                                              */
/******************************************************************************/

/* Initialize port IO functions, directionality, initial-state. */
void initIO(void) {
    // SPI Module Initialization.
    TRISBbits.TRISB10 = 0b1;    // SDI (Input)
    TRISBbits.TRISB11 = 0b1;    // SCK (Input)
    
    ANSBbits.ANSB13 = 0b0;      // Set Digital
    TRISBbits.TRISB13 = 0b0;    // SDO (Output)
    
    ANSBbits.ANSB15 = 0b0;      // Set RB15 Digital
    TRISBbits.TRISB15 = 0b1;    // Set RB15 as Input
    
    // Digital-to-Analog Converter Peripheral Initialization.
    // DAC1 - Light Refraction
    ANSBbits.ANSB12 = 0b1;      // RB12 (Pin 23) digital function disabled.
    TRISBbits.TRISB12 = 0b0;    // RB12 set output.
    // DAC2 - Light Transmission
    ANSBbits.ANSB14 = 0b1;      // RB14 (Pin 25) digital function disabled.
    TRISBbits.TRISB14 = 0b0;    // RB14 set output.

    // Photoluminescence IO (Excitation) Initialization.
    TRISAbits.TRISA7 = 0b0;    // Set RA7 output.
    LATAbits.LATA7 = 0b0;     // Set RA7 low.
    
    // Analog-to-Digital Converter Peripheral Initialization.
    // Optical transmission.
    ANSAbits.ANSA2 = 0b1;       // RA2 set analog.
    TRISAbits.TRISA2 = 0b1;     // RA2 set input.
    // Photoluminescence.
    ANSAbits.ANSA3 = 0b1;       // RA3
    TRISAbits.TRISA3 = 0b1;
    // Optical Refraction.
    ANSAbits.ANSA4 = 0b1;
    TRISAbits.TRISA4 = 0b1;
    // Reference Voltage
    ANSAbits.ANSA0 = 0b1;
    TRISAbits.TRISA0 = 0b1;
    // Reference Thermistor
    ANSBbits.ANSB5 = 0b1;
    TRISBbits.TRISB5 = 0b1;
    
    // AVDD Supply Control
    ANSBbits.ANSB3 = 0b0;
    TRISBbits.TRISB3 = 0b0;
    LATBbits.LATB3 = 0b1;
}

/* Initialize DAC registers. */
void initDAC(void) {
    // DAC Register 1 (Transmission) Initialization
    DAC1CON = 0x8082; // DAC initialization, VREF+ AVDD, no trigger.
    DAC1DAT = 0x0000; // Initialize 0V.
    // DAC Register 2 (Refraction) Initialization
    DAC2CON = 0x8082; // DAC initialization, mimic DAC1CON register.
    DAC2DAT = 0x0000; // Initialize 0V.
}

/* Initialize ADC registers. */
void initADC(void) {
    // ADC Register 1
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.MODE12 = 0b1;       // Mode (12/10-bit).
    AD1CON1bits.FORM = 0b00;        // Data justification/type.
    AD1CON1bits.SSRC = 0b0111;      // Sample clock source select.
    AD1CON1bits.ASAM = 0b0;
    AD1CON1bits.SAMP = 0b0;

    AD1CON2bits.PVCFG = 0b0;        // VDD source.
    AD1CON2bits.NVCFG0 = 0b0;       // VSS source.
    AD1CON2bits.BUFREGEN = 0b0;     // FIFO / Match.
    AD1CON2bits.SMPI = 0b00000;     // Sample# per interrupt flag set.
    AD1CON2bits.BUFM = 0b0;

    AD1CON3bits.ADRC = 0b0;         // ADC conversion clock source.
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0b0001;      // Conversion clock scaler (X*Tcy).
}

/* Initialize TIMER registers. */
void initTIMER(void) {
    T1CON = 0x0000;         // Register set T1 OFF initial, FOSC/2, 1:1 pre-scaler. (250ns)
    PR1 = 0x0138;
}

void initSPI(void) {
    SSP1STATbits.SMP = 0b0;
    SSP1STATbits.CKE = 0b1;
    
    SSP1CON1bits.SSPEN = 0b1;
    SSP1CON1bits.CKP = 0b0;
    SSP1CON1bits.SSPM = 0b0100;
    
    SSP1CON3bits.BOEN = 0b0;
    PADCFG1 = 0x0C00;   // SDO2/SCK2/SCK1 output disabled.
}

/******************************************************************************/
/* User Operation Functions                                                   */
/******************************************************************************/
void clearOverflow(void) {
    if (SSP1CON1bits.SSPOV) {
        SSP1CON1bits.SSPOV = 0b0;
    }
}

void flushBuffer(void) {
    sByte = SSP1BUF;
}

unsigned char exchangeByte(unsigned char data) {
    clearOverflow();
    SSP1BUF = data;
    while(!SSP1STATbits.BF){;}  
    return SSP1BUF;
}

void exchangeInt(unsigned int sVar) {
    rByte = (char) sVar;
    for (k=0;k<4;k++) {
        rByte = exchangeByte(rByte); 
    }
    rByte = (char) (sVar >> 8);
    for (k=0;k<4;k++) {
        rByte = exchangeByte(rByte);    
    }
}

// Optical Excitation Function Implementations
void opticalTransmission(void) {
    // ADC Initialization.
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0x0A;        // Conversion clock scaler (X*Tcy).
    AD1CON1bits.ADON = 0b1;
    AD1CHS = 0x000D;            // Set RA3 (AN14) active.
    IFS0bits.AD1IF = 0b0;
    
    k=0;
    j=0;

    counter = 0x0000;         // Reset counter.
    dacIndex = 0x00;
    
    IFS0bits.T1IF = 0b0;
    TMR1 = PR1;
    T1CONbits.TON = 0b1;
    
    // Stabilization time.
    DAC2DAT = sineLookupT[0];   // Initial DAC register load.
    while (j < 0x2F) {
    }
    
    // Filter acquisition chain.
    AD1CON1bits.ASAM = 0b1;
    while (counter < 800) {
    }
    
    // De-initialize ADC.
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.ASAM = 0b0;
    IFS0bits.AD1IF = 0b0;
    
    T1CONbits.TON = 0b0;    // Stop timer.
    IFS0bits.T1IF = 0b0;
    
    DAC1DAT = 0x0000;
    DAC2DAT = 0x0000;   // Re-initialize DAC state off.
}

// Optical Refraction Function Implementation
void opticalRefraction(void) {
    // ADC Initialization.
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0x0A;        // Conversion clock scaler (X*Tcy).
    AD1CON1bits.ADON = 0b1;
    AD1CHS = 0x0010;            // Set RA3 (AN14) active.
    IFS0bits.AD1IF = 0b0;
    
    k=1;
    j=0;

    counter = 0x0000;         // Reset counter.
    dacIndex = 0x00;
    
    IFS0bits.T1IF = 0b0;
    TMR1 = PR1;
    T1CONbits.TON = 0b1;
    
    // Stabilization time.
    DAC1DAT = sineLookupR[0] >> 2;   // Initial DAC register load.
    while (j < 0x2F) {
    }
    
    // Filter acquisition chain.
    AD1CON1bits.ASAM = 0b1;
    while (counter < 800) {
    }
    
    // De-initialize ADC.
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.ASAM = 0b0;
    IFS0bits.AD1IF = 0b0;
    
    T1CONbits.TON = 0b0;    // Stop timer.
    IFS0bits.T1IF = 0b0;
    
    DAC1DAT = 0x0000;
    DAC2DAT = 0x0000;   // Re-initialize DAC state off.
}

// Photoluminescence Acquisition function.
void opticalPhotoluminescence(void) {
    // ADC Initialization.
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0b1;      // Conversion clock scaler (X*Tcy).
    AD1CON1bits.ADON = 0b1;
    AD1CHS = 0x000E;            // Set RA3 (AN14) active.
    IFS0bits.AD1IF = 0b0;
    
    // Reset indexing/completion.
    counter = 0;
    
    // FET LED Driver Switch
    LATAbits.LATA7 = 0b1;      // LED ON.
    for (k=0;k<1;k++) {
        for (i=0;i<1000;i++) {
            __builtin_nop();
        }
    }
    LATAbits.LATA7 = 0b0; // LED driver off.
    
    // Start sampling.
    AD1CON1bits.ASAM = 0b1;
    while (counter<800){};
    
    // De-initialize ADC.
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.ASAM = 0b0;
    IFS0bits.AD1IF = 0b0;
}

// Measure reference temperature.
void referenceTemperature(void) {
    // Module Initializations  
    AD1CHS = 0x0011;                   // Select channel RB5 (AN17). 
    IFS0bits.AD1IF = 0b0;
    
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0x0A;      // Conversion clock scaler (X*Tcy).
    AD1CON1bits.ADON = 0b1;
    
    counter = 0x0000;
    AD1CON1bits.ASAM = 0b1;
    while (counter < 0x28) {  
    }
    
    // De-initialize ADC.
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.ASAM = 0b0;
    IFS0bits.AD1IF = 0b0;
}

// Measure reference voltage.
void referenceVoltage(void) {
    // Module Initializations
    AD1CHS = 0x0000;
    IFS0bits.AD1IF = 0b0;
    
    AD1CON3bits.SAMC = 0b00101;     // Auto-sample time (X*Tad).
    AD1CON3bits.ADCS = 0x0A;      // Conversion clock scaler (X*Tcy).
    AD1CON1bits.ADON = 0b1;
    
    counter = 0x0000;
    AD1CON1bits.ASAM = 0b1;
    while (counter < 0x0A) {  
    }
    
    // De-initialize ADC.
    AD1CON1bits.ADON = 0b0;
    AD1CON1bits.ASAM = 0b0;
    IFS0bits.AD1IF = 0b0; 
}