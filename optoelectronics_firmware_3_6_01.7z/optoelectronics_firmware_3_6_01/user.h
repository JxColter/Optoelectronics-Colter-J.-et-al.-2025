/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/

/* TODO Application specific user parameters used in user.c may go here */

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

/* Initialization */
void initIO(void);      // IO and Peripheral Initialization.
void initDAC(void);     // DAC Initialization.
void initADC(void);     // ADC Initialization.
void initSPI(void);     // SPI-FTDI Module Interface Initialization.
void initTIMER(void);   // Timer Module Initialization.

/* Operation */
// SPI USB Functions
void clearOverflow(void);
void flushBuffer(void);
unsigned char exchangeByte(unsigned char data);
void exchangeInt(unsigned int sVar);

void sendInt(unsigned int sVar);             // Return data (0xXXXX) to interface.
unsigned char spiRead(void);
void spiWrite(unsigned char tx);

// Optical Control Functions
void opticalTransmission(void);                // Optical Transmit Function.
void opticalRefraction(void);                  // Optical Refraction Function.
void opticalPhotoluminescence(void);      // Optical Photoluminescence Function.

// Temperature, voltage references.
void referenceTemperature(void);
void referenceVoltage(void);