/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
#include <xc.h>
#elif defined(__C30__)
#if defined(__PIC24E__)
#include <p24Exxxx.h>
#elif defined (__PIC24F__)||defined (__PIC24FK__)
#include <p24Fxxxx.h>
#elif defined(__PIC24H__)
#include <p24Hxxxx.h>
#endif
#endif

#include <stdint.h>        /* Includes uint16_t definition                    */
#include <stdbool.h>       /* Includes true/false definition                  */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp              */
#include "global.h"
#include "interrupts.h"

/******************************************************************************/
/* Global Variable Declaration                                                */
/******************************************************************************/
// Sine Wave Look-up Table

volatile unsigned int sineLookupR[50] = {
    0x4,0x5,0x5,0x5,0x6,0x6,0x7,0x7,0x7,0x8,
    0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x7,0x7,0x7,
    0x6,0x6,0x5,0x5,0x5,0x4,0x3,0x3,0x3,0x2,
    0x2,0x1,0x1,0x1,0x0,0x0,0x0,0x0,0x0,0x0,
    0x0,0x0,0x1,0x1,0x1,0x2,0x2,0x3,0x3,0x3,
};

// YAG LED
volatile unsigned int sineLookupT[50] = {
    0xa,0xb,0xc,0xe,0xf,0x10,0x11,0x12,0x12,0x13,
    0x14,0x14,0x14,0x14,0x14,0x14,0x13,0x12,0x12,0x11,
    0x10,0xf,0xe,0xc,0xb,0xa,0x9,0x8,0x6,0x5,
    0x4,0x3,0x2,0x2,0x1,0x0,0x0,0x0,0x0,0x0,
    0x0,0x1,0x2,0x2,0x3,0x4,0x5,0x6,0x8,0x9,
};


volatile unsigned int counter = 0x0000;           // Track sample counter.
volatile unsigned char dacIndex = 0x00;          // Track look-up table counter.
volatile unsigned char scale = 0x00;
volatile unsigned char tExc = 0x00;
volatile unsigned char flush = 0x00;

// Data buffer variable.
volatile unsigned int dataBuffer[800] = {};

// Receive and transmit variables.
volatile unsigned char rByte = 0x00;
volatile unsigned char sByte = 0x00;
volatile unsigned char rx = 0x00;

// For-loop increment declaration.
volatile unsigned int i = 0;
volatile unsigned int j = 0;
volatile unsigned int k = 0;

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

int16_t main(void) {

    /* Configure the oscillator for the device. */
    configureOscillator();

    /* Initialize IO ports and peripherals. */
    initIO();
    initDAC();
    initSPI();
    initTIMER();
    initADC();
    initInterrupts();
    
    /* Main program loop */
    while (1) {
        rByte = exchangeByte(0x00);
        //rByte = spiRead();
        //spiWrite(rByte);
        
        // Function calls from controller
        switch (rByte) {
            // Initial case.
            case 0x00:
                break;
                
            // Optical Transmission   
            case 0x01:
                // Delay
                for (i=0;i<255;i++){;}
                // Transmission Acquisition
                opticalTransmission();
                // Data transfer
                flushBuffer();
                i=0;
                while (i<800) {
                    exchangeInt(dataBuffer[i]);
                    i++;
                }
                break;
                
            case 0x02:
                // Delay
                for (i=0;i<255;i++){;}
                // Refraction acquisition
                opticalRefraction();
                // Data transfer
                flushBuffer();
                i=0;
                while (i<800) {
                    exchangeInt(dataBuffer[i]); 
                    i++;
                }
                break;
            
            case 0x03:
                // Delay
                for (i=0;i<255;i++){;}
                // Photoluminescence acquisition
                opticalPhotoluminescence();              
                // Data transfer
                flushBuffer();
                i=0;
                while (i<800) {
                    exchangeInt(dataBuffer[i]); 
                    i++;
                }              
                break;
                
            case 0x04:
                // Delay
                for (i=0;i<255;i++){;}
                // Temperature acquisition
                referenceTemperature();
                // Data transfer
                flushBuffer();
                i=0;
                while (i<10) {
                    exchangeInt(dataBuffer[i]);
                    i++;
                }
                break;

            case 0x05:
                // Delay
                for (i=0;i<255;i++){;}
                // Reference Voltage acquisition
                referenceVoltage();
                // Data transfer
                flushBuffer();
                i=0;
                while (i<10) {
                    exchangeInt(dataBuffer[i]);  
                    i++;
                }
                break;
                
            // Default case.
            default:
                break;           
        }
    }
}

