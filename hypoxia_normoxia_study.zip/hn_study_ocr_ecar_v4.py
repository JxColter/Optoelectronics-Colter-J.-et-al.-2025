import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Constants
start_index = 750
window_size = 75  # Custom range for averaging

# Base directory for processed data
base_dir = 'data_consolidated_amplitudes'
output_dir = 'ecar_ocr'
os.makedirs(output_dir, exist_ok=True)

def load_data(file_path):
    with open(file_path, 'r') as f:
        return np.array([float(line.strip()) for line in f])

def shift_to_zero(signal):
    return signal - signal[start_index]

def normalize_across_conditions(normoxia, hypoxia):
    combined = np.concatenate([normoxia, hypoxia])
    min_val, max_val = np.min(combined), np.max(combined)
    normoxia = (normoxia - min_val) / (max_val - min_val)
    hypoxia = (hypoxia - min_val) / (max_val - min_val)
    return normoxia, hypoxia

def estimate_oxygen_concentration(norm_pl, k_sv=2.0, i0=1.0):
    """
    Estimate oxygen concentration using Stern–Volmer quenching dynamics.
    
    Parameters:
    - norm_pl: normalized photoluminescence signal (0 < norm_pl ≤ i0)
    - k_sv: Stern–Volmer constant (default: 2.0)
    - i0: unquenched intensity (default: 1.0)
    
    Returns:
    - Estimated oxygen concentration [O2]
    """
    # norm_pl = np.clip(norm_pl, 1e-3, i0)  # Avoid division by zero or negative values
    # o2 = (i0 / norm_pl - 1) / k_sv
    # return o2

    o2 = (norm_pl - 0.1) * (18.5 - 3.5) / (0.8 - 0.1) + 3.5
    return o2

def ocr_calc(pl, cell, time, window):
    oxy = estimate_oxygen_concentration(pl)  # Convert PL to oxygen concentration
    ocr = []
    list_dO2 = []
    for i in range(start_index, len(oxy) - window, window):
        dO2 = oxy[i] - oxy[i + window]
        list_dO2.append(dO2)

        dCell = np.abs(cell[i + int(window/2)])
        dTime = time[i + window] - time[i]
        ocr.append(dO2 / dCell / dTime)
    return np.array(ocr), list_dO2

def ecar_calc(ph, cell, time, window):
    ecar = []
    for i in range(start_index, len(ph) - window, window):
        dPH = ph[i + window] - ph[i]
        dCell = np.abs(cell[i + int(window/2)])
        dTime = time[i + window] - time[i]
        ecar.append(dPH / dCell / dTime)
    return np.array(np.abs(ecar))

def remove_outliers(data, m=3.0):
    mean = np.mean(data)
    std = np.std(data)
    return data[np.abs(data - mean) < m * std]

# Load and preprocess signals
conditions = ['normoxia', 'hypoxia']
pl_data = {}
rf_data = {}
tx_data = {}
dt_data = {}

for cond in conditions:
    pl_data[cond] = load_data(os.path.join(base_dir, f'processed_pl_{cond}.txt'))
    rf_data[cond] = shift_to_zero(load_data(os.path.join(base_dir, f'processed_rf_{cond}.txt')))
    tx_data[cond] = shift_to_zero(load_data(os.path.join(base_dir, f'processed_tx_{cond}.txt')))
    dt_data[cond] = np.divide(load_data(os.path.join(base_dir, f'processed_dt_{cond}.txt')), 3600 * 24)

# Normalize signals across conditions
rf_data['normoxia'], rf_data['hypoxia'] = normalize_across_conditions(rf_data['normoxia'], rf_data['hypoxia'])
tx_data['normoxia'], tx_data['hypoxia'] = normalize_across_conditions(tx_data['normoxia'], tx_data['hypoxia'])

# Calculate OCR and ECAR using custom range
ocr_data = {}
ecar_data = {}
dO2_data = {}

for cond in conditions:
    ocr_data[cond], dO2_data[cond] = ocr_calc(pl_data[cond], rf_data[cond], dt_data[cond], window_size)
    ecar_data[cond] = ecar_calc(tx_data[cond], rf_data[cond], dt_data[cond], window_size)

# # Normalize OCR and ECAR to shared range
# min_len_ocr = min(len(ocr_data['normoxia']), len(ocr_data['hypoxia']))
# min_len_ecar = min(len(ecar_data['normoxia']), len(ecar_data['hypoxia']))

# all_ocr = np.concatenate([ocr_data['normoxia'][:min_len_ocr], ocr_data['hypoxia'][:min_len_ocr]])
# all_ecar = np.concatenate([ecar_data['normoxia'][:min_len_ecar], ecar_data['hypoxia'][:min_len_ecar]])

# ocr_min, ocr_max = np.min(all_ocr), np.max(all_ocr)
# ecar_min, ecar_max = np.min(all_ecar), np.max(all_ecar)

# ocr_data['normoxia'] = (ocr_data['normoxia'][:min_len_ocr] - ocr_min) / (ocr_max - ocr_min)
# ocr_data['hypoxia'] = (ocr_data['hypoxia'][:min_len_ocr] - ocr_min) / (ocr_max - ocr_min)
# ecar_data['normoxia'] = (ecar_data['normoxia'][:min_len_ecar] - ecar_min) / (ecar_max - ecar_min)
# ecar_data['hypoxia'] = (ecar_data['hypoxia'][:min_len_ecar] - ecar_min) / (ecar_max - ecar_min)

# Remove outliers
ocr_data['normoxia'] = remove_outliers(ocr_data['normoxia'])
ocr_data['hypoxia'] = remove_outliers(ocr_data['hypoxia'])
ecar_data['normoxia'] = remove_outliers(ecar_data['normoxia'])
ecar_data['hypoxia'] = remove_outliers(ecar_data['hypoxia'])

# Plot OCR violin
fig, ax = plt.subplots(layout='constrained')
plt.title('Estimated OCR (Clustered, Custom Range)')
sns.violinplot(data=[ocr_data['normoxia'], ocr_data['hypoxia']], inner='quartile', bw=0.5, scale='width', palette='icefire')
ax.set_xticklabels(['Normoxia', 'Hypoxia'])
ax.set_ylabel('Normalized OCR [mol/cell/s]')
plt.savefig(os.path.join(output_dir, 'OCR_violin_clustered_custom_range.png'), dpi=300)
plt.close()

# Plot ECAR violin
fig, ax = plt.subplots(layout='constrained')
plt.title('Estimated ECAR (Clustered, Custom Range)')
sns.violinplot(data=[ecar_data['normoxia'], ecar_data['hypoxia']], inner='quartile', bw=0.5, scale='width', palette='icefire')
ax.set_xticklabels(['Normoxia', 'Hypoxia'])
ax.set_ylabel('Normalized ECAR [$\\Delta$pH/cell/s]')
plt.savefig(os.path.join(output_dir, 'ECAR_violin_clustered_custom_range.png'), dpi=300)
plt.close()

print("✅ Clustered violin plots with custom range saved to ecar_ocr/")

# plt.figure(figsize=(10, 4))
# plt.plot(estimate_oxygen_concentration(pl_data['normoxia']), label='O2 (Normoxia)')
# plt.plot(estimate_oxygen_concentration(pl_data['hypoxia']), label='O2 (Hypoxia)')
# plt.legend()
# plt.title('Estimated Oxygen Concentration (Stern–Volmer)')
# plt.show()

# fig, ax = plt.subplots(layout='constrained')
# plt.title('dO2 (Clustered, Custom Range)')
# sns.violinplot(data=[dO2_data['normoxia'], dO2_data['hypoxia']], inner='point', palette='icefire')
# ax.set_xticklabels(['Normoxia', 'Hypoxia'])
# ax.set_ylabel('Normalized OCR [mol/cell/s]')
# plt.savefig(os.path.join(output_dir, 'dO2_violin_clustered_custom_range.png'), dpi=300)
# plt.close()

# plt.figure(figsize=(10, 4))
# plt.plot(dO2_data['normoxia'], label='O2 (Normoxia)')
# plt.plot(dO2_data['hypoxia'], label='O2 (Hypoxia)')
# plt.legend()
# plt.title('Estimated Oxygen Concentration (Stern–Volmer)')
# plt.show()

# plt.figure(figsize=(10, 4))
# plt.plot(rf_data['normoxia'], label='Cell Signal (Normoxia)')
# plt.plot(rf_data['hypoxia'], label='Cell Signal (Hypoxia)')
# plt.legend()
# plt.title('Cell Signal Over Time')
# plt.show()