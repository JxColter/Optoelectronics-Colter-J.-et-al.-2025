import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set working directory
base_dir = r"C:/Users/jxcol/Documents/Professional/Projects/2025 Colter et al Instrumentation/data_code_files/hypoxia_normoxia_study"
input_folder = os.path.join(base_dir, 'data_consolidated_amplitudes')
output_folder = os.path.join(base_dir, 'data_consol_vis', 'amp_coeff')
os.makedirs(output_folder, exist_ok=True)

# Plot style
sns.set_style('darkgrid')
sns.set_context('notebook', font_scale=2.5, rc={"font.weight": "bold"})

# Load time delta data for each condition
time_data_days = {}
for condition in ['hypoxia', 'normoxia']:
    try:
        time_data_days[condition] = np.loadtxt(os.path.join(input_folder, f'processed_dt_{condition}.txt')) / (3600 * 24)
    except FileNotFoundError:
        print(f"Warning: Time file for {condition} not found.")

# Signal file keys and plotting parameters
signal_files = {
    'Photoluminescence': ('pl', 'darkblue', [0, 1]),
    'Transmission': ('tx', 'darkred', [0, 1]),
    'Scatter': ('rf', 'darkkhaki', [0, 2]),
    'Temperature': ('temp', 'hotpink', [0, 2.5]),
    'Vref': ('vref', 'slategray', [2.5, 2.6])
}

# # Invert scatter data
# def invert_data(data):
#     data = np.array(data)
#     mask = data > 1.2
#     data[mask] = 1.5 + (1.5 - data[mask])
#     return data

# Load data from file
def load_data(file_path):
    with open(file_path, 'r') as f:
        return [float(line.strip()) for line in f]

# Normalize using global min-max
def normalize_minmax_global(data, global_min, global_max):
    data = np.array(data)
    return (data - global_min) / (global_max - global_min) if global_max > global_min else data

# Compute global min and max for DO Coefficient
do_data_all = []
for condition in ['hypoxia', 'normoxia']:
    file_path = os.path.join(input_folder, f"processed_pl_{condition}.txt")
    if os.path.exists(file_path):
        do_data_all.extend(load_data(file_path))
global_min_do = min(do_data_all)
global_max_do = max(do_data_all)

# Plotting loop
for condition in ['hypoxia', 'normoxia']:
    fig, axes = plt.subplots(1, 5, figsize=(45, 8))
    for idx, (title, (signal_key, color, ylim)) in enumerate(signal_files.items()):
        filename = f"processed_{signal_key}_{condition}.txt"
        file_path = os.path.join(input_folder, filename)
        print(f"Loading {file_path} for {condition}")

        if os.path.exists(file_path):
            data = load_data(file_path)
            # if title == 'Scatter':
                # data = invert_data(data)
            if title == 'Photoluminescence':
                data = normalize_minmax_global(data, global_min_do, global_max_do)

            time_array = time_data_days.get(condition, [])
            min_len = min(len(time_array), len(data))
            time_trimmed = time_array[:min_len]
            data_trimmed = data[:min_len]

            axes[idx].plot(time_trimmed[500:], data_trimmed[500:], color=color)
            axes[idx].set_title(title, fontsize=45)
            axes[idx].set_xlabel('Time (Days)', fontsize=40)
            axes[idx].tick_params(axis='both', labelsize=35)
            y_labels = {
                'Photoluminescence': 'Normalized DO (a.u.)',
                'Transmission': 'Amplitude (Volts)',
                'Scatter': 'Amplitude (Volts)',
                'Temperature': 'Amplitude (Volts)',
                'Vref': 'Amplitude (Volts)'
            }
            axes[idx].set_ylabel(y_labels.get(title, 'Signal'), fontsize=40)
            axes[idx].set_xlim([0.9, 4.1])
            axes[idx].set_ylim(ylim)
        else:
            print(f"Warning: {file_path} not found.")

    # fig.suptitle(f"{condition.capitalize()} Signal Overview", fontsize=28, weight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, f"{condition}.png"))
    plt.close()
    print(f"{condition} plotted.")