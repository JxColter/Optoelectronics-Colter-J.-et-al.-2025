import os
import numpy as np
import matplotlib.pyplot as plt

window_set = 100
start_set=500
end_set=2200


def load_data(file_path):
    with open(file_path, 'r') as file:
        data = [float(line.strip()) for line in file]
    return data



def detect_perturbation(temp_data, threshold=0.002, window_size=window_set, start=start_set, end=end_set):
    perturbation_start = None
    perturbation_end = None

    mean_temp = np.mean(temp_data[start - window_size:start])

    for i in range(start, end):
        if abs(temp_data[i] - mean_temp) > threshold:
            perturbation_start = i
            break


    if perturbation_start is not None:
        mean_temp = np.mean(temp_data[end - window_size:end])
        for i in range(perturbation_start, end):
            if abs(temp_data[i] - mean_temp) <= threshold:
                perturbation_end = i
                break

    return perturbation_start, perturbation_end



def correct_data(data, perturbation_start, perturbation_end, window_size=window_set):
    mean_before_perturbation = np.mean(data[perturbation_start - window_size:perturbation_start])
    mean_after_perturbation = np.mean(data[perturbation_end:perturbation_end + window_size])
    
    shift_value = mean_before_perturbation - mean_after_perturbation

    corrected_data = data.copy()
    corrected_data[perturbation_start:perturbation_end] = [mean_before_perturbation] * (perturbation_end - perturbation_start)
    corrected_data[perturbation_end:] = [x + shift_value for x in data[perturbation_end:]]

    return corrected_data

def ocr_calc(oxy_in, cell_in, time_in, window_size=window_set, start=start_set, end=end_set):
    cell_in = np.subtract(cell_in, cell_in[start])
    ocr_eq = []
    time_eq = []

    for i in range(start, end):
        ocr_eq.append((np.mean(oxy_in[i:i+window_size])-np.mean(oxy_in[i-window_size:i])) / np.abs((cell_in[i+1]-cell_in[start])) / (time_in[i]-time_in[i-window_size]))
        time_eq.append(time_in[i])
    
    return ocr_eq, time_eq

def ecar_calc(ph_in, cell_in, time_in, window_size=window_set, start=start_set, end=end_set):
    ph_in = np.subtract(ph_in, ph_in[start])
    cell_in = np.subtract(cell_in, cell_in[start])

    ph_eq = []
    time_eq = []
    
    for i in range(start, end):
        ph_eq.append((np.mean(ph_in[i:i+window_size])-np.mean(ph_in[i-window_size:i])) / np.abs((cell_in[i+1]-cell_in[start])) / (time_in[i+window_size]-time_in[i-window_size]))
        time_eq.append(time_in[i])
    
    return ph_eq, time_eq




def plot_experiment(experiment, replicate):

    # Define the input folders
    input_folder = 'data_consolidated_amplitudes'
    delta_time_folder = os.path.join(input_folder, 'delta_time')
    coeff_DO_folder = os.path.join(input_folder, 'coeff_DO')
    amp_pH_folder = os.path.join(input_folder, 'amp_pH')
    amp_scatter_folder = os.path.join(input_folder, 'amp_scatter')
    amp_temp_folder = os.path.join(input_folder, 'amp_temp')
    amp_vref_folder = os.path.join(input_folder, 'amp_vref')

    # Load delta_time data for the selected experiment
    delta_time_file = os.path.join(delta_time_folder, f'time_delta_{experiment}dtc.txt')
    delta_time_data = np.divide(load_data(delta_time_file), (3600 * 24))  # Convert seconds to days
    print(len(delta_time_data))

    # Load other measurement data for the selected experiment and replicate
    coeff_DO_file = os.path.join(coeff_DO_folder, f'coeff_DO_{experiment}_{replicate}.txt')
    coeff_DO_data = load_data(coeff_DO_file)

    amp_pH_file = os.path.join(amp_pH_folder, f'amp_pH_{experiment}_{replicate}.txt')
    amp_pH_data = load_data(amp_pH_file)

    amp_scatter_file = os.path.join(amp_scatter_folder, f'amp_scatter_{experiment}_{replicate}.txt')
    amp_scatter_data = load_data(amp_scatter_file)

    amp_temp_file = os.path.join(amp_temp_folder, f'amp_temp_{experiment}_{replicate}.txt')
    amp_temp_data = load_data(amp_temp_file)

    amp_vref_file = os.path.join(amp_vref_folder, f'amp_vref_{experiment}_{replicate}.txt')
    amp_vref_data = load_data(amp_vref_file)


    # Detect perturbation in temperature data
    perturbation_start, perturbation_end = detect_perturbation(amp_temp_data)
    print([perturbation_start, perturbation_end])
    # Correct scatter and pH data relative to temperature perturbations
    amp_pH_data = correct_data(amp_pH_data, perturbation_start, perturbation_end)
    amp_scatter_data = correct_data(amp_scatter_data, perturbation_start, perturbation_end)

    ocr, t_ocr = ocr_calc(coeff_DO_data, amp_scatter_data, delta_time_data)
    ecar, t_ecar = ecar_calc(amp_pH_data, amp_scatter_data, delta_time_data)

    # # Plot the data
    # plt.figure()
    # plt.subplot(2, 1, 1)
    # plt.plot(t_ocr, np.abs(ocr), label='ocr')
    # plt.xlabel('Time (Days)')
    # plt.title('OCR')
    # plt.legend()
    # plt.subplot(2, 1, 2)
    # plt.plot(t_ecar, np.abs(ecar), label='Amplitude pH', color='orange')
    # plt.xlabel('Time (Days)')
    # plt.title('ECAR')
    # plt.legend()
    # plt.tight_layout()
    # plt.savefig(f'data_consol_vis/ocr_ecar/{experiment}_{replicate}.png')
    # plt.show(), plt.close()

    return ocr, t_ocr, ecar, t_ecar

experiment = 'h100'  # Change this to the desired experiment
replicate = '1'      # Change this to the desired replicate
c1_ocr, t_c1_ocr, c1_ecar, t_c1_ecar = plot_experiment(experiment, replicate)
experiment = 'n100'  # Change this to the desired experiment
replicate = '1'      # Change this to the desired replicate
c2_ocr, t_c2_ocr, c2_ecar, t_c2_ecar = plot_experiment(experiment, replicate)

c1_ocr = np.abs(c1_ocr)
c2_ocr = np.abs(c2_ocr)
c1_ecar = np.abs(c1_ecar)
c2_ecar = np.abs(c2_ecar)


c1_ocr = [x for x in c1_ocr if x < 1000]
c2_ocr = [x for x in c2_ocr if x < 1000]
c1_ecar = [x for x in c1_ecar if x < 600]
c2_ecar = [x for x in c2_ecar if x < 600]

# Function to calculate the average of every 2 consecutive samples
def average_consecutive_samples(arr, n=35):
    return [np.mean(arr[i:i+n]) for i in range(0, len(arr), n)]

# Adjust the c1 and c2 variables
c1_ocr_avg = average_consecutive_samples(c1_ocr)
c2_ocr_avg = average_consecutive_samples(c2_ocr)
c1_ecar_avg = average_consecutive_samples(c1_ecar)
c2_ecar_avg = average_consecutive_samples(c2_ecar)

from sklearn.preprocessing import MinMaxScaler

def normalize_to_range(arr):
    scaler = MinMaxScaler()
    arr = np.array(arr).reshape(-1, 1)
    normalized_arr = scaler.fit_transform(arr).flatten()
    return normalized_arr

ocr = [c1_ocr_avg, c2_ocr_avg]
ecar = [c1_ecar_avg, c2_ecar_avg]
ocr_norm = normalize_to_range(ocr)*1.5e-16
ecar_norm = normalize_to_range(ecar)*5e-12

c1_ocr_norm = ocr_norm[:len(c1_ocr_avg)]
c2_ocr_norm = ocr_norm[len(c1_ocr_avg):]

c1_ecar_norm = ecar_norm[:len(c1_ecar_avg)]
c2_ecar_norm = ecar_norm[len(c1_ecar_avg):]

import seaborn as sns
sns.set_style('darkgrid')
sns.set_context('notebook', font_scale=2)

fig, ax = plt.subplots(layout='constrained')
plt.title('Estimated OCR (Clustered)')
sns.violinplot(data=[c2_ocr_norm, c1_ocr_norm], inner='point', palette='icefire', bw=0.6)
ax.set_xticklabels(['Normoxia', 'Hypoxia'])
ax.set_ylabel('OCR [mol/cell/s]')
plt.savefig('data_consol_vis/ocr_ecar/ocr_comparison.png', dpi=600)
fig, ax = plt.subplots(layout='constrained')
plt.title('Estimated ECAR (Clustered)')
sns.violinplot(data=[c2_ecar_norm, c1_ecar_norm], inner='point', palette='icefire', bw=0.6)
ax.set_xticklabels(['Normoxia', 'Hypoxia'])
ax.set_ylabel('ECAR [$\\Delta$pH/cell/s]')
plt.savefig('data_consol_vis/ocr_ecar/ecar_comparison.png', dpi=600)

plt.show(), plt.close()

