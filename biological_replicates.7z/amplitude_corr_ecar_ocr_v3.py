import os
import numpy as np
import matplotlib.pyplot as plt

# Constants
window_set = 100
start_set = 500
end_set = 2200

def load_data(file_path):
    with open(file_path, 'r') as file:
        return [float(line.strip()) for line in file]

def detect_perturbation(temp_data, threshold=0.002, window_size=window_set, start=start_set, end=end_set):
    mean_temp = np.mean(temp_data[start - window_size:start])
    for i in range(start, end):
        if abs(temp_data[i] - mean_temp) > threshold:
            perturbation_start = i
            break
    else:
        return None, None

    mean_temp = np.mean(temp_data[end - window_size:end])
    for i in range(perturbation_start, end):
        if abs(temp_data[i] - mean_temp) <= threshold:
            perturbation_end = i
            break
    else:
        return perturbation_start, None

    return perturbation_start, perturbation_end

def correct_data(data, perturbation_start, perturbation_end, window_size=window_set):
    mean_before = np.mean(data[perturbation_start - window_size:perturbation_start])
    mean_after = np.mean(data[perturbation_end:perturbation_end + window_size])
    shift_value = mean_before - mean_after

    corrected = data.copy()
    corrected[perturbation_start:perturbation_end] = [mean_before] * (perturbation_end - perturbation_start)
    corrected[perturbation_end:] = [x + shift_value for x in data[perturbation_end:]]
    return corrected

def ocr_calc(oxy, cell, time, start=start_set, end=end_set):
    cell = np.subtract(cell, cell[start])
    ocr, t = [], []
    for i in range(start, end):
        dO2 = oxy[i+1] - oxy[i]
        dCell = np.abs(cell[i+1] - cell[start])
        dTime = time[i+1] - time[i]
        ocr.append(dO2 / dCell / dTime)
        t.append(time[i])
    return ocr, t

def ecar_calc(ph, cell, time, start=start_set, end=end_set):
    ph = np.subtract(ph, ph[start])
    cell = np.subtract(cell, cell[start])
    ecar, t = [], []
    for i in range(start, end):
        dPH = ph[i+1] - ph[i]
        dCell = np.abs(cell[i+1] - cell[start])
        dTime = time[i+1] - time[i]
        ecar.append(dPH / dCell / dTime)
        t.append(time[i])
    return ecar, t

def plot_experiment(experiment, replicate):
    base = 'data_consolidated_amplitudes'
    delta_time = load_data(os.path.join(base, 'delta_time', f'time_delta_{experiment}dtc.txt'))
    delta_time = np.divide(delta_time, 3600 * 24)

    coeff_DO = load_data(os.path.join(base, 'coeff_DO', f'coeff_DO_{experiment}_{replicate}.txt'))
    amp_pH = load_data(os.path.join(base, 'amp_pH', f'amp_pH_{experiment}_{replicate}.txt'))
    amp_scatter = load_data(os.path.join(base, 'amp_scatter', f'amp_scatter_{experiment}_{replicate}.txt'))
    amp_temp = load_data(os.path.join(base, 'amp_temp', f'amp_temp_{experiment}_{replicate}.txt'))

    p_start, p_end = detect_perturbation(amp_temp)
    amp_pH = correct_data(amp_pH, p_start, p_end)
    amp_scatter = correct_data(amp_scatter, p_start, p_end)

    ocr, t_ocr = ocr_calc(coeff_DO, amp_scatter, delta_time)
    ecar, t_ecar = ecar_calc(amp_pH, amp_scatter, delta_time)

    os.makedirs('ecar_ocr', exist_ok=True)

    plt.figure()
    plt.plot(t_ocr, np.abs(ocr), label='OCR')
    plt.xlabel('Time (Days)')
    plt.ylabel('OCR [mol/cell/s]')
    plt.title(f'OCR Over Time ({experiment} {replicate})')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f'ecar_ocr/{experiment}_{replicate}_OCR.png', dpi=300)
    plt.close()

    plt.figure()
    plt.plot(t_ecar, np.abs(ecar), label='ECAR', color='orange')
    plt.xlabel('Time (Days)')
    plt.ylabel('ECAR [ΔpH/cell/s]')
    plt.title(f'ECAR Over Time ({experiment} {replicate})')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f'ecar_ocr/{experiment}_{replicate}_ECAR.png', dpi=300)
    plt.close()

# Example usage
plot_experiment('h100', '1')
plot_experiment('n100', '1')
