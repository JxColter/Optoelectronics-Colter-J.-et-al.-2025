import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
import os
from scipy.stats import permutation_test

sns.set_style('darkgrid')
sns.set_context('notebook', font_scale=3, rc={"font.weight": "bold"})

def invert_data(data):
    initial_point = 1.8
    inverted_data = np.copy(data)
    for k in range(1, len(inverted_data)):
        if inverted_data[k] > 1.5:
            inverted_data[k] = initial_point + (initial_point - inverted_data[k])
    return inverted_data

def quantile_loess(data, window_size=200, quantile=.5):
    n = len(data)
    smoothed_data = np.zeros(n)
    for i in range(n):
        start = max(0, i - window_size // 2)
        end = min(n, i + window_size // 2 + 1)
        window_data = data[start:end]
        smoothed_data[i] = np.quantile(window_data, quantile)
    return smoothed_data

def load_data(file_path):
    with open(file_path, 'r') as file:
        data = [float(line.strip()) for line in file]
    return data

def calculate_rate_of_change(smoothed_data, delta_time_data):
    rate_of_change = np.diff(smoothed_data) / np.diff(delta_time_data[:len(smoothed_data)])
    return rate_of_change
def calculate_rate_of_change_perturb(smoothed_data, delta_time_data):
    rate_of_change = np.diff(smoothed_data) / np.diff(delta_time_data[:len(smoothed_data)])
    return rate_of_change[rate_of_change < np.mean(rate_of_change)]

def calculate_mean_and_normalize(coeff_DO_data, amp_scatter_data, amp_pH_data, delta_time_data):
    smoothed_coeff_DO_data = quantile_loess(coeff_DO_data)
    smoothed_amp_scatter_data = quantile_loess(amp_scatter_data)
    smoothed_amp_pH_data = quantile_loess(amp_pH_data)

    #smoothed_coeff_DO_data = smoothed_coeff_DO_data / smoothed_amp_scatter_data
    #smoothed_amp_pH_data = smoothed_amp_pH_data / smoothed_amp_scatter_data
    n = 5
    rate_of_change_DO = calculate_rate_of_change_perturb(smoothed_coeff_DO_data[n:-n], delta_time_data[n:-n])
    rate_of_change_transmission = calculate_rate_of_change(smoothed_amp_pH_data[n:-n], delta_time_data[n:-n])

    return rate_of_change_DO, rate_of_change_transmission

def plot_experiment(experiment):
    input_folder = 'data_consolidated_amplitudes'
    delta_time_folder = os.path.join(input_folder, 'delta_time')
    coeff_DO_folder = os.path.join(input_folder, 'coeff_DO')
    amp_pH_folder = os.path.join(input_folder, 'amp_pH')
    amp_scatter_folder = os.path.join(input_folder, 'amp_scatter')
    amp_temp_folder = os.path.join(input_folder, 'amp_temp')
    amp_vref_folder = os.path.join(input_folder, 'amp_vref')

    delta_time_file = os.path.join(delta_time_folder, f'time_delta_{experiment[:-2]}dtc.txt')
    if not os.path.exists(delta_time_file):
        print(f"File not found: {delta_time_file}")
        return
    delta_time_data = np.divide(load_data(delta_time_file), (3600 * 24))

    coeff_DO_file = os.path.join(coeff_DO_folder, f'coeff_DO_{experiment}.txt')
    if not os.path.exists(coeff_DO_file):
        print(f"File not found: {coeff_DO_file}")
        return
    coeff_DO_data = load_data(coeff_DO_file)

    amp_pH_file = os.path.join(amp_pH_folder, f'amp_pH_{experiment}.txt')
    if not os.path.exists(amp_pH_file):
        print(f"File not found: {amp_pH_file}")
        return
    amp_pH_data = load_data(amp_pH_file)

    amp_scatter_file = os.path.join(amp_scatter_folder, f'amp_scatter_{experiment}.txt')
    if not os.path.exists(amp_scatter_file):
        print(f"File not found: {amp_scatter_file}")
        return
    amp_scatter_data = load_data(amp_scatter_file)

    if experiment == 'n100_1':
        amp_scatter_data = invert_data(amp_scatter_data)

    amp_temp_file = os.path.join(amp_temp_folder, f'amp_temp_{experiment}.txt')
    if not os.path.exists(amp_temp_file):
        print(f"File not found: {amp_temp_file}")
        return
    amp_temp_data = load_data(amp_temp_file)

    amp_vref_file = os.path.join(amp_vref_folder, f'amp_vref_{experiment}.txt')
    if not os.path.exists(amp_vref_file):
        print(f"File not found: {amp_vref_file}")
        return
    amp_vref_data = load_data(amp_vref_file)

    normalized_rate_of_change_DO, normalized_rate_of_change_transmission = calculate_mean_and_normalize(coeff_DO_data, amp_scatter_data, amp_pH_data, delta_time_data)
    
    print(f'{experiment} - Normalized Rate of Change in DO: {normalized_rate_of_change_DO.mean():.4f} min-1')
    print(f'{experiment} - Normalized Rate of Change in Transmission: {normalized_rate_of_change_transmission.mean():.4f} min-1')

    return normalized_rate_of_change_DO.mean(), normalized_rate_of_change_transmission.mean()

def plot_running_averages(experiment):
    input_folder = 'data_consolidated_amplitudes'
    delta_time_folder = os.path.join(input_folder, 'delta_time')
    coeff_DO_folder = os.path.join(input_folder, 'coeff_DO')
    amp_pH_folder = os.path.join(input_folder, 'amp_pH')
    amp_scatter_folder = os.path.join(input_folder, 'amp_scatter')

    delta_time_file = os.path.join(delta_time_folder, f'time_delta_{experiment[:-2]}dtc.txt')
    if not os.path.exists(delta_time_file):
        print(f"File not found: {delta_time_file}")
        return
    delta_time_data = np.divide(load_data(delta_time_file), (3600 * 24))

    coeff_DO_file = os.path.join(coeff_DO_folder, f'coeff_DO_{experiment}.txt')
    if not os.path.exists(coeff_DO_file):
        print(f"File not found: {coeff_DO_file}")
        return
    coeff_DO_data = load_data(coeff_DO_file)

    amp_pH_file = os.path.join(amp_pH_folder, f'amp_pH_{experiment}.txt')
    if not os.path.exists(amp_pH_file):
        print(f"File not found: {amp_pH_file}")
        return
    amp_pH_data = load_data(amp_pH_file)

    amp_scatter_file = os.path.join(amp_scatter_folder, f'amp_scatter_{experiment}.txt')
    if not os.path.exists(amp_scatter_file):
        print(f"File not found: {amp_scatter_file}")
        return
    amp_scatter_data = load_data(amp_scatter_file)

    if experiment == 'n100_1':
        amp_scatter_data = invert_data(amp_scatter_data)

    smoothed_coeff_DO_data = quantile_loess(coeff_DO_data)
    smoothed_amp_scatter_data = quantile_loess(amp_scatter_data)
    smoothed_amp_pH_data = quantile_loess(amp_pH_data)

    plt.figure(figsize=(45, 15))

    plt.subplot(3, 1, 1)
    plt.plot(delta_time_data[:len(smoothed_coeff_DO_data)], smoothed_coeff_DO_data, label='Smoothed Coeff DO')
    plt.xlabel('Time (Days)')
    plt.ylabel('Coefficient (s-1)')
    plt.title('Smoothed Coefficient DO')

    plt.subplot(3, 1, 2)
    plt.plot(delta_time_data[:len(smoothed_amp_scatter_data)], smoothed_amp_scatter_data, label='Smoothed Scatter', color='green')
    plt.xlabel('Time (Days)')
    plt.ylabel('Amplitude (Volts)')
    plt.title('Smoothed Scatter')

    plt.subplot(3, 1, 3)
    plt.plot(delta_time_data[:len(smoothed_amp_pH_data)], smoothed_amp_pH_data, label='Smoothed Transmission', color='orange')
    plt.xlabel('Time (Days)')
    plt.ylabel('Amplitude (Volts)')
    plt.title('Smoothed Transmission')

    plt.tight_layout()
    plt.savefig(f'data_filtered_vis/{experiment}_quantile_loess.png')
    plt.close()

experiments = ['n100_1', 'n120_1','n150_1', 'n150_2', 'h100_1', 'h100_2', 'h150_0', 'h150_2']
batch_a = experiments # ['n100_1', 'h100_1', 'h100_2', 'h150_2']
batch_b = ['n120_1', 'n150_1', 'n150_2', 'h150_0']

do_rates_a = []
transmission_rates_a = []
do_rates_b = []
transmission_rates_b = []

for experiment in batch_a:
    do_rate, transmission_rate = plot_experiment(experiment)
    do_rates_a.append(do_rate)
    transmission_rates_a.append(transmission_rate)

# for experiment in batch_b:
#     do_rate, transmission_rate = plot_experiment(experiment)
#     do_rates_b.append(do_rate)
#     transmission_rates_b.append(transmission_rate)

# Normalize within each batch
do_rates_a = np.array(do_rates_a)
transmission_rates_a = np.array(transmission_rates_a)
do_rates_a_normalized = do_rates_a
transmission_rates_a_normalized = transmission_rates_a

# do_rates_b = np.array(do_rates_b)
# transmission_rates_b = np.array(transmission_rates_b)
# do_rates_b_normalized = do_rates_b-np.min(do_rates_b)
# do_rates_b_normalized /= np.max(do_rates_b_normalized)
# transmission_rates_b_normalized = transmission_rates_b

# Separate normalized data into H and N specific arrays
do_rates_normoxia = []
do_rates_hypoxia = []
transmission_rates_normoxia = []
transmission_rates_hypoxia = []

for i, experiment in enumerate(batch_a):
    if 'n' in experiment:
        do_rates_normoxia.append(do_rates_a_normalized[i])
        transmission_rates_normoxia.append(transmission_rates_a_normalized[i])
    else:
        do_rates_hypoxia.append(do_rates_a_normalized[i])
        transmission_rates_hypoxia.append(transmission_rates_a_normalized[i])

# for i, experiment in enumerate(batch_b):
#     if 'n' in experiment:
#         do_rates_normoxia.append(do_rates_b_normalized[i])
#         transmission_rates_normoxia.append(transmission_rates_b_normalized[i])
#     else:
#         do_rates_hypoxia.append(do_rates_b_normalized[i])
#         transmission_rates_hypoxia.append(transmission_rates_b_normalized[i])


# Combine the normalized data for plotting
do_rates_combined = np.concatenate([do_rates_normoxia, do_rates_hypoxia])
do_rates_combined = np.abs(do_rates_combined)
do_rates_combined /= np.max(do_rates_combined)

transmission_rates_combined = np.concatenate([transmission_rates_normoxia, transmission_rates_hypoxia])
transmission_rates_combined = np.abs(transmission_rates_combined)
transmission_rates_combined /= np.max(transmission_rates_combined)

labels_do_combined = ['Normoxia'] * len(do_rates_normoxia) + ['Hypoxia'] * len(do_rates_hypoxia)
labels_trans_combined = ['Normoxia'] * len(transmission_rates_normoxia) + ['Hypoxia'] * len(transmission_rates_hypoxia)

# Define the statistic function for permutation test
def statistic(x, y):
    return np.mean(x) - np.mean(y)

# Calculate p-values using permutation test
result_do = permutation_test((do_rates_normoxia, do_rates_hypoxia), statistic=statistic, alternative='two-sided')
pval_do = result_do.pvalue

result_transmission = permutation_test((transmission_rates_normoxia, transmission_rates_hypoxia), statistic=statistic, alternative='two-sided')
pval_transmission = result_transmission.pvalue

# Plot boxplots
plt.figure(figsize=(12, 40))  # Increase figure size to provide more y space

deep_blue = '#4C72B0'
deep_red = '#C44E52'

plt.subplot(2, 1, 1)
sns.boxplot(x=labels_do_combined, y=do_rates_combined, palette=[deep_blue, deep_red], showfliers=False, whis=[0, 100])
plt.ylabel('Fold Difference in Rate')
plt.title('Oxygen Consumption')
# plt.ylim(-0.1, max(do_rates_combined) * 1.3)  # Increase y-limit to provide more space

# Add p-value annotation
# plt.plot([0, 1], [max(do_rates_combined) * 1.2, max(do_rates_combined) * 1.2], color='black')
# plt.text(0.5, max(do_rates_combined) * 1.25, f'pval={pval_do:.2f}', ha='center')

plt.subplot(2, 1, 2)
sns.boxplot(x=labels_trans_combined, y=transmission_rates_combined, palette=[deep_blue, deep_red], showfliers=False, whis=[0, 100])
plt.title('Extracellular Acidification')
plt.ylabel('Fold Difference in Rate')

# plt.ylim(-0.1, max(transmission_rates_combined) * 1.3)  # Increase y-limit to provide more space

# Add p-value annotation
# plt.plot([0, 1], [max(transmission_rates_combined) * 1.2, max(transmission_rates_combined) * 1.2], color='black')
# plt.text(0.5, max(transmission_rates_combined) * 1.25, f'pval={pval_transmission:.2f}', ha='center')

plt.tight_layout()
plt.savefig('avg.png', dpi=300)
# plt.show()
