__author__ = "James Colter"
__copyright__ = "Copyright 2024, hiPSC Optoelectronics Project"
__credits__ = ["James Colter, Kartikeya Murari"]
__license__ = "GPL"
__version__ = "1.19.7.1"
__maintainer__ = "James Colter"
__email__ = "jdcolter@ucalgary.ca"
__status__ = "Prototype Production"

# # Library Inclusions               
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import datetime
import pickle
import scipy
import matplotlib.pyplot as plt
import statsmodels.api as sm


# # Functions
def import_file(file_string):

    #   Stores file contents as array (file pointer/iterator is more efficient for processing large files)

    # Parameters:
        #   file_string - file path

    # Returns:
        # file_in - numpy ndarray object
    
    file_in = np.genfromtxt(file_string, delimiter = '\n', dtype='float')    # Parse file into ndarray
    return file_in[:,:-1]                                                    # Remove end of line NaN prior to return



def parse_timeline(datetime_data, num_acquisitions, averaging):

    # References stored datetime data against initial value to decode relative temporal information.

    # Parameters:
        #   datetime_file - ndarray containing contents of datetime (dt) file (e.g. datetime_data = import_file("dt.txt"))
        #   num_acquisitions - integer containing number of acquisitions in file (number of lines)
        #   averaging - integer, user defined, based on averaging desired for processing

    # Returns:
        # time_seconds - ndarray
        # time_hours - ndarray
        # time_days - ndarray


    j = 0   # Reference counter variable
    time_seconds = np.zeros(int(num_acquisitions/averaging))

    for i in range(0, num_acquisitions, averaging):
        time_seconds[j] = datetime_data[i]-datetime_data[0]
        j += 1

    time_hours = time_seconds/3600
    time_days = time_hours/24

    return time_seconds, time_hours, time_days



def parse_temperature(temperature_data, gate_threshold):

    # Compute mean temperature in volts and degrees, alongside voltage drift for reference data.
    # Calculate normalized differential temperature, and compute gate values from user threshold.
    # Note that degree calculation based on thermistor application data:
    # https://www.murata.com/en-us/api/pdfdownloadapi?cate=luNTCforTempeSenso&partno=NCU18XH103F60RB

    # Parameters:
        # temperature_data - ndarray containing imported file data (e.g. import_file('mcutemp.txt'))
        # gate_threshold - float, user defined value for threshold

    # Returns:
        # temperature_mean_volts - ndarray
        # temperature_volts_drift - ndarray
        # temperature_mean_degrees - ndarray
        # temp_degree_differential - ndarray
        # temperature_gate - ndarray

    temperature_mean_volts = np.zeros(len(temperature_data[:,0]))
    temperature_mean_degrees = np.zeros(len(temperature_data[:,0]))

    for i in range(len(temperature_data[:,0])):
        temperature_mean_volts[i] = np.mean(temperature_data[i,:])
        temperature_mean_degrees[i] = 1 / ((np.log(((3.3e4/temperature_mean_volts[i])-1e4)/1e4)/3300)+(1/298.15))

    temperature_volts_drift = temperature_mean_volts - temperature_mean_volts[0]

    temp_degree_differential = (temperature_mean_degrees - np.min(temperature_mean_degrees)) \
        / (np.max(temperature_mean_degrees)-np.min(temperature_mean_degrees))
    
    temperature_gate = np.zeros(len(temperature_data[:,0]))
    for i in range(len(temp_degree_differential)):
        if temp_degree_differential[i] < gate_threshold:
            temperature_gate[i] = 0
        else:
            temperature_gate[i] == 1

    return temperature_mean_volts, temperature_volts_drift, temperature_mean_degrees, \
        temp_degree_differential, temperature_gate



def parse_reference_voltage(reference_voltage_data, temperature_correlation):

    # Organize reference voltage into mean values, drift relative to initial measurement.
    # Calculate temperature correlated drift (requires empirical estimation / fitting to quantify correlation)

    # Parameters:
        # reference_voltage_data - ndarray containing reference data (e.g. import_file('mcuvref.txt'))
        # temperature_correlation - float describing voltage fluctuation relative to temperature

    # Returns:
        # mean_ref_voltage - ndarray
        # ref_voltage_drift - ndarray
        # volt_temp_correlation - ndarray

    mean_ref_voltage = np.zeros(len(reference_voltage_data[:,0]))

    for i in range(len(reference_voltage_data[:,0])):
        mean_ref_voltage[i] = np.mean(reference_voltage_data[i,:])
    
    ref_voltage_drift = mean_ref_voltage - mean_ref_voltage[0]

    volt_temp_correlation = ref_voltage_drift * temperature_correlation

    return mean_ref_voltage, ref_voltage_drift, volt_temp_correlation




def parse_tx_rf(tx_rf_data, gating_function, correction_range):

    # Average amplitude data into float values per acquisition, and remove artifacts associated with \
    # perturbation as a result of manual disruption during protocols.

    # Parameters: 
        # tx_rf_data - ndarray containing transmission OR refraction data associated with system
        # gating_function - ndarray, temperature associated perturbation function for artifact removal
        # correction_range - integer containing range for averaging to be applied in correction

    # Returns:
        # tx_rf_amplitude - ndarray, mean amplitude data across acquisitions
        # tx_rf_artifactrem - ndarray, amplitude dataset following perturbation removal
    
    tx_rf_amplitude = np.zeros(len(tx_rf_data[:,0]))

    for i in range(len(tx_rf_amplitude)):
        max_tx_rf = []
        min_tx_rf = []

        for j in len(1, tx_rf_data[i,:-1]):
            if (tx_rf_data[i,j] > tx_rf_data[i,j-1]) and (tx_rf_data[i,j] > tx_rf_data[i,j+1]):
                max_tx_rf.append(tx_rf_data[i, j])
            elif (tx_rf_data[i,j] > tx_rf_data[i,j-1]) and (tx_rf_data[i,j] > tx_rf_data[i,j+1]):
                min_tx_rf.append(tx_rf_data[i, j])   

        tx_rf_amplitude[i] = np.mean(max_tx_rf) - np.mean(min_tx_rf)
    
    tx_rf_artifactrem = np.zeros(len(tx_rf_data[:, 0]))

    k = 0
    for i in range(len(tx_rf_artifactrem)):
        if (gating_function[i] == 0):
            k+=1
        else:
            if (k > 0):
                if (i < int(correction_range/2)):
                    tx_rf_artifactrem[0:i] = np.mean(tx_rf_amplitude[i:i+correction_range])
                    tx_rf_artifactrem[i-k:] += tx_rf_amplitude[0]-tx_rf_amplitude[i]
                else:
                    tx_rf_artifactrem[i-k:i] = np.mean(tx_rf_amplitude[i-int(correction_range/2):i+int(correction_range/2)])
                    tx_rf_artifactrem[i-k:] += np.mean(tx_rf_amplitude[i-k-int(correction_range/2):i-k-1]-tx_rf_amplitude[i]) 
            k=0
        if (i==len(tx_rf_artifactrem)-1):
            tx_rf_artifactrem[i-k:] = np.mean(tx_rf_amplitude[i-k-correction_range:i-k])

    return tx_rf_amplitude, tx_rf_artifactrem
    


def parse_pl(pl_data, acquisition_axis, amplifier_response, AC_coupling, pl_estimate):

    # Transform photoluminescence acquisitions and fit a two-phase exponential to estimate coefficients.

    # Parameters: 
        # pl_data - ndarray containing photoluminescence data
        # acquisition_axis - ndarray (temporal axis of sequential sampling time over course of single acquisition)
        # amplifier_response - integer or float (initial value based on response time in absence of emission)
        # AC_coupling - integer or float (voltage from which exponential decay is observed - design dependent)
        # pl_estimate - initial guess for lifetime coefficient associated with photoluminescence

    # Returns:
        # tx_rf_amplitude - ndarray, mean amplitude data across acquisitions
        # tx_rf_artifactrem - ndarray, amplitude dataset following perturbation removal

    transform1_pl = np.zeros(np.shape(pl_data))

    for i in range(len(pl_data[:,0])):
        for j in range(len(pl_data[0,:])):
            transform1_pl[i, j] = np.max(pl_data[i,:]-pl_data[i,j])

    def twophase_exponential(x, m1, t1, m2, t2):
        return (m1 * np.exp(-t1 * x)) + (m2 * np.exp(-t2 * x))
    
    m1_pl, t1_pl, m2_pl, t2_pl = np.zeros(len(pl_data[:,0])), np.zeros(len(pl_data[:,0])), \
        np.zeros(len(pl_data[:,0])), np.zeros(len(pl_data[:,0]))
    
    init_estimate = (AC_coupling, amplifier_response, AC_coupling, pl_estimate)

    for i in range(len(pl_data[:,0])):
        paramsB, cv = scipy.optimize.curve_fit(twophase_exponential, acquisition_axis, transform1_pl[i], \
                                               init_estimate, maxfev=10000)
        m1_pl[i], t1_pl[i], m2_pl[i], t2_pl[i] = paramsB

    return transform1_pl, m1_pl, t1_pl, m2_pl, t2_pl



def model_rel_cell_density(cell_data, rf_combined_set, refraction_model_out):
    # Calculates linear ordinary least squares coefficients given input x and y data. Plots results to \
    # a .sav file using the pickle library.

    # Parameters:
        # cell_data - ndarray containing empirical cell data from offline measurements, associated with each refraction set
        # rf_combined_set - ndarray containing voltage data for all refraction sets used in model
        # refraction_model_out - string containing filename to store model parameters.
    
    # Returns:
        # None (creates a .sav file with model parameters)

    x_train = rf_combined_set.reshape(rf_combined_set.shape[0], 1)
    y_train = cell_data.reshape(cell_data.shape[0], 1)

    model = sm.OLS(y_train, sm.add_constant(x_train))
    model_fit = model.fit()

    print(model_fit.summary())

    pickle.dump(model, open(refraction_model_out, 'wb'))

    return



def relative_cell_density(rf_data_processed, refraction_model_in):

    # Calculates CHANGE in cell density relative to voltage differential observed in refraction channel.
    # Utilizes model parameters saved in a .sav file (see model_rel_cell_density function).

    # Parameters:
        # rf_data_processed - ndarray containing refraction data for which relative change in cell density is to be estimated
        # refraction_model_in - string containing path for .sav file containing model parameters

    # Returns:
        # differential_cell_density - ndarray

    import pickle

    loaded_model = pickle.load(open(refraction_model_in, 'rb'))

    zero_ref_rf_data = rf_data_processed - rf_data_processed[0]

    differential_cell_density = loaded_model.predict(zero_ref_rf_data.reshape(zero_ref_rf_data.shape[0], 1))

    return differential_cell_density



def calculate_pH(tx_data_processed, calibration_parameters, rf_reference_data, gain_distance, tx_nought):
    
    # Calculate pH using calibration data, for a given transmission dataset. Because transmission is \
    # still subject to scattering, a correction can be made given the corresponding refraction dataset to estimate losses.

    # Parameters:
        # tx_data_processed - ndarray containing transmission data for processing
        # calibration_parameters - array containing linear coefficients corresponding to calibration data (slope, intercept)
        # rf_reference_data - ndarray with rf data for the same run, used to estimate scattering applied to transmission channel
        # gain_distance - float corresponding to difference in gains between channels and optical path distance
        # tx_nought - float, denoting intensity of the system in the absence of absorbing species

    # Returns:
        # tx_data_corrected - ndarray containing scatter-corrected transmission data
        # tx_beer_lambert - ndarray containing differential absorption as calculated by Beer-Lambert law
        # pH_differential_calibrated - ndarray containing differential pH as calculated by functions

    tx_data_corrected = (tx_data_processed-tx_data_processed[0]) + ((rf_reference_data-rf_reference_data[0])*gain_distance)

    tx_beer_lambert = np.negative(np.log10(tx_data_corrected/tx_nought))

    def applied_calibration(absorbance_data, cal_params):
        return ((absorbance_data - absorbance_data[0]) - cal_params[1]) / cal_params[0]

    pH_differential_calibrated = applied_calibration(tx_beer_lambert, calibration_parameters)

    return tx_data_corrected, tx_beer_lambert, pH_differential_calibrated



def calculate_DO(lifetime_coefficients, kq, tnought, atmospheric_pressure):

    # Calculate dissolved oxygen concentration given calibration values for kq and tnought using Stern-Volmer relation.
    # Convert molar concentration of dissolved oxygen to a percent dissolved oxygen value.

    # Parameters:
        # lifetime_coefficients - ndarray containing lifetime coefficients as calculated in parse_pl() function.
        # kq - float containing empirically calculated kq from calibration data.
        # tnought - float containing empirically calculated tnought from calibration data.
        # atmospheric_pressure - float containing ambient atmospheric pressure to estimate percent DO.

    # Returns:
        # molar_conc_DO - ndarray containing calculated molar dissolved oxygen concentration [Q] from Stern-Volmer relation
        # percent_DO - ndarray containing percent dissolved oxygen

    molar_conc_DO = ((tnought/lifetime_coefficients)-1) / (tnought*kq)

    RT = 0.08134*(273.15+37)

    percent_DO = 100 * (molar_conc_DO * RT / atmospheric_pressure)

    return molar_conc_DO, percent_DO      



def OCR_calculation(dissolved_oxygen_in, reference_data_in, purge, temporal_axis, cell_data, volume_vessel, data_range):

    # Calculate cell- and vessel-normalized oxygen consumption rate in the system given a set of dissolved oxygen values.
    # Note that in a purge condition, reference data is applied to attempt to correct for non-homeostatic oxygen losses.
    # Purge data in the absence of cells is normalized to purge data in the presence of cells by cell density in calculations.

    # Parameters:
        #   dissolved_oxygen_in - ndarray containing DO over experiment time-course
        #   reference_data_in - ndarray data used to correct purge condition
        #   purge - boolean, informs purge condition
        #   temporal_axis - array containing temporal information
        #   cell_data - ndarray containing estimated cell density (cells/mL)
        #   volume_vessel - float defining vessel volume
        #   data_range - integer, distance to average from boundary for differential calculation

    # Returns:
        # Purge-corrected OCR - ndarray containing OCR, corrected against reference if purge condition is true.

    volume_cell = volume_vessel * 1e3 # Conversion of liters to milliliters for cell/mL calculation

    if purge == 0:
        reference_data_in = np.zeros(len(dissolved_oxygen_in))

    def reference_differential(input, init, ref_init, final, ref_final):
        return np.abs(np.mean(input[init-ref_init:init])-np.mean(input[final:final+ref_final]))
        
    def reference_cell(input, init, ref_init, final, ref_final):
        return np.mean(input[init-ref_init:final+ref_final])
    
    oxygen_consumption_rate, OCR_reference = np.zeros(len(dissolved_oxygen_in)), np.zeros(len(dissolved_oxygen_in))
    reference_time = np.zeros(len(temporal_axis))

    for i in range(data_range, len(dissolved_oxygen_in)-data_range-1, 1):
        reference_time[i] = reference_differential(temporal_axis, i, data_range, i, data_range)
        oxygen_consumption_rate[i] = (volume_vessel*(reference_differential(dissolved_oxygen_in, i, data_range, i, data_range))) / (reference_time*volume_cell*reference_cell(cell_data, i, data_range, i, data_range))
        OCR_reference[i] = (volume_vessel*(reference_differential(reference_data_in, i, data_range, i, data_range))) / (reference_time*volume_cell*reference_cell(cell_data, i, data_range, i, data_range))
    for i in range(len(dissolved_oxygen_in)-2*data_range-1, len(dissolved_oxygen_in)-1, 1):
        reference_time = reference_differential(temporal_axis, i-2*data_range, data_range, i-data_range, data_range)
        oxygen_consumption_rate[i] = ((volume_vessel*(reference_differential(dissolved_oxygen_in, i-2*data_range, data_range, i-data_range, data_range))) / (reference_time*volume_cell*reference_cell(cell_data, i-2*data_range, data_range, i-data_range, data_range)))

    return np.abs(oxygen_consumption_rate - OCR_reference)


    
def ECAR_calculation(pH_in, temporal_axis, cell_data, volume_vessel, data_range):

    # Calculate cell- and vessel-normalized pH rate of change in the system given pH and cell density.

    # Parameters:
        #   pH_in - ndarray containing pH over experiment time-course
        #   temporal_axis - array containing temporal information
        #   cell_data - ndarray containing estimated cell density (cells/mL)
        #   volume_vessel - float defining vessel volume
        #   data_range - integer, distance to average from boundary for differential calculation

    # Returns:
        #  extracellular_acidification - ndarray containing OCR, corrected against reference if purge condition is true.

    volume_cell = volume_vessel * 1e3 # Conversion of liters to milliliters for cell/mL calculation

    def reference_differential(input, init, ref_init, final, ref_final):
        return np.abs(np.mean(input[init-ref_init:init])-np.mean(input[final:final+ref_final]))
        
    def reference_cell(input, init, ref_init, final, ref_final):
        return np.mean(input[init-ref_init:final+ref_final])
    
    extracellular_acidification = np.zeros(len(pH_in))

    for i in range(data_range, len(pH_in)-data_range-1, 1):
        reference_time = reference_differential(temporal_axis, i, data_range, i, data_range)
        extracellular_acidification[i] = (reference_differential(pH_in, i, data_range, i, data_range)) / (reference_time*volume_cell*reference_cell(cell_data, i, data_range, i, data_range))
    for i in range(len(pH_in)-2*data_range-1, len(pH_in)-1, 1):
        reference_time = reference_differential(temporal_axis, i-2*data_range, data_range, i-data_range, data_range)
        extracellular_acidification[i] = (reference_differential(pH_in, i-2*data_range, data_range, i-data_range, data_range)) / (reference_time*volume_cell*reference_cell(cell_data, i-2*data_range, data_range, i-data_range, data_range))
    
    return extracellular_acidification


# EOF