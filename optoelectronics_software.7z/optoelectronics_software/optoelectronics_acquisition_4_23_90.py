__author__ = "James Colter"
__copyright__ = "Copyright 2024, hiPSC Optoelectronics Project"
__credits__ = ["James Colter, Kartikeya Murari"]
__license__ = "GPL"
__version__ = "4.23.9.0"
__maintainer__ = "James Colter"
__email__ = "jdcolter@ucalgary.ca"
__status__ = "Prototype Production"

# Library Inclusions
import pprint       # Structure printing functions
import time         # Timing function library
import serial                       # pySerial library functions
import serial.tools.list_ports

import sys          # System library functions
import numpy        # Mathematics library functions.
import numpy as np

import datetime

# Constant Inclusions
pp = pprint.PrettyPrinter(indent=4)     # Pretty printer declaration

try:
    spi.close(freeze=False)
except:
    pass

# Software timing constraints
hours = 0
seconds = 0
runtime = (hours * 3600) + seconds                 # Program runtime in seconds
acqTotal = 20000

# Function acquisition user interface variables (Select)
txS = 0
rfS = 0
plS = 1
tempS = 1
vrefS = 1

# Delay timing
acqDelay = 6
if (acqDelay < 0):
    acqDelay = 0

# Check Devices
from pyftdi.ftdi import Ftdi
Ftdi.show_devices()

pp.pprint(Ftdi.show_devices())

from pyftdi.spi import SpiController, SpiIOError

spi = SpiController()
spi.configure('ftdi://ftdi:232h:0:1/1')
slave = spi.get_port(cs=0, freq=1e5, mode=0)

pp.pprint("Connected at address ftdi://ftdi:232h:0:1/1"), print()

#write_buf = bytearray([0])
#pp.pprint(write_buf)
#read_buf = slave.exchange(out=write_buf, readlen=5, duplex=True)
#pp.pprint(read_buf)
#int_buf = [x for x in read_buf]
#pp.pprint(int_buf)

# Data file access code.
try:
    # Microcontroller files. - Board 0
    mcutx0 = open("mcutx0.txt", "w+")
    mcurf0 = open("mcurf0.txt", "w+")
    mcupl0 = open("mcupl0.txt", "w+")
    mcutemp0 = open("mcutemp0.txt", "w+")
    mcuvref0 = open("mcuvref0.txt", "w+")
    # Microcontroller files. - Board 1
    mcutx1 = open("mcutx1.txt", "w+")
    mcurf1 = open("mcurf1.txt", "w+")
    mcupl1 = open("mcupl1.txt", "w+")
    mcutemp1 = open("mcutemp1.txt", "w+")
    mcuvref1 = open("mcuvref1.txt", "w+")
    # Microcontroller files. - Board 2
    mcutx2 = open("mcutx2.txt", "w+")
    mcurf2 = open("mcurf2.txt", "w+")
    mcupl2 = open("mcupl2.txt", "w+")
    mcutemp2 = open("mcutemp2.txt", "w+")
    mcuvref2 = open("mcuvref2.txt", "w+")
    # Microcontroller files. - Board 3
    mcutx3 = open("mcutx3.txt", "w+")
    mcurf3 = open("mcurf3.txt", "w+")
    mcupl3 = open("mcupl3.txt", "w+")
    mcutemp3 = open("mcutemp3.txt", "w+")
    mcuvref3 = open("mcuvref3.txt", "w+")
    # Datetime file.
    dt = open("dt.txt", "w+")

except Exception:
        print("Unable to open one or more files.")
        sys.exit(0)


# ----------------- Program Functions ---------------- #
## Transmitted light MCU operation.
def tx():
    local = np.zeros(1600*4)

    write_buf = np.array(np.ones(1), dtype='ubyte')
    pp.pprint(write_buf.tobytes())

    spi.flush()

    read_buf = slave.exchange(out=write_buf.tobytes(), readlen=4, start=True, stop=False, duplex=True)
    
    time.sleep(1)

    for i in range(0, 6400, 4):
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+1] = int.from_bytes(read_buf, byteorder = 'big', signed = False) 
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+2] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+3] = int.from_bytes(read_buf, byteorder = 'big', signed = False)

    for i in range(0, 6400, 8):
        x0 = float(local[i] + (local[i+4]*256))*(3.3/4096)
        x1 = float(local[i+1] + (local[i+5]*256))*(3.3/4096)
        x2 = float(local[i+2] + (local[i+6]*256))*(3.3/4096)
        x3 = float(local[i+3] + (local[i+7]*256))*(3.3/4096)

        mcutx0.write("%f \t" % x0)
        mcutx1.write("%f \t" % x1)
        mcutx2.write("%f \t" % x2)
        mcutx3.write("%f \t" % x3)

        mcutx0.flush(), mcutx1.flush(), mcutx2.flush(), mcutx3.flush()

    mcutx0.write("\n"), mcutx1.write("\n"), mcutx2.write("\n"), mcutx3.write("\n")
    mcutx0.flush(), mcutx1.flush(), mcutx2.flush(), mcutx3.flush()

## Refracted light MCU operation.
def rf():
    local = np.zeros(1600*4)

    write_buf = np.array(np.ones(1)*2, dtype='ubyte')
    pp.pprint(write_buf.tobytes())

    spi.flush()

    read_buf = slave.exchange(out=write_buf.tobytes(), readlen=4, start=True, stop=False, duplex=True)
    
    time.sleep(1)

    for i in range(0, 6400, 4):
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+1] = int.from_bytes(read_buf, byteorder = 'big', signed = False) 
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+2] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+3] = int.from_bytes(read_buf, byteorder = 'big', signed = False)

    for i in range(0, 6400, 8):
        x0 = float(local[i] + (local[i+4]*256))*(3.3/4096)
        x1 = float(local[i+1] + (local[i+5]*256))*(3.3/4096)
        x2 = float(local[i+2] + (local[i+6]*256))*(3.3/4096)
        x3 = float(local[i+3] + (local[i+7]*256))*(3.3/4096)

        mcurf0.write("%f \t" % x0)
        mcurf1.write("%f \t" % x1)
        mcurf2.write("%f \t" % x2)
        mcurf3.write("%f \t" % x3)

        mcurf0.flush(), mcurf1.flush(), mcurf2.flush(), mcurf3.flush()

    mcurf0.write("\n"), mcurf1.write("\n"), mcurf2.write("\n"), mcurf3.write("\n")
    mcurf0.flush(), mcurf1.flush(), mcurf2.flush(), mcurf3.flush()



## Photoluminescence MCU operation.
def pl():
    local = np.zeros(1600*4)

    write_buf = np.array(np.ones(1)*3, dtype='ubyte')
    pp.pprint(write_buf.tobytes())
    spi.flush()
    read_buf = slave.exchange(out=write_buf.tobytes(), readlen=4, start=True, stop=False, duplex=True)
    
    time.sleep(0.5)

    for i in range(0, 6400, 4):
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+1] = int.from_bytes(read_buf, byteorder = 'big', signed = False) 
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+2] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+3] = int.from_bytes(read_buf, byteorder = 'big', signed = False)

    for i in range(0, 6400, 8):
        x0 = float(local[i] + (local[i+4]*256))*(3.3/4096)
        x1 = float(local[i+1] + (local[i+5]*256))*(3.3/4096)
        x2 = float(local[i+2] + (local[i+6]*256))*(3.3/4096)
        x3 = float(local[i+3] + (local[i+7]*256))*(3.3/4096)

        mcupl0.write("%f \t" % x0)
        mcupl1.write("%f \t" % x1)
        mcupl2.write("%f \t" % x2)
        mcupl3.write("%f \t" % x3)

        mcupl0.flush(), mcupl1.flush(), mcupl2.flush(), mcupl3.flush()

    mcupl0.write("\n"), mcupl1.write("\n"), mcupl2.write("\n"), mcupl3.write("\n")
    mcupl0.flush(), mcupl1.flush(), mcupl2.flush(), mcupl3.flush()



# Thermistor MCU operation.
def temp():
    local = np.zeros(20*4)

    write_buf = np.array(np.ones(1)*4, dtype='ubyte')
    pp.pprint(write_buf.tobytes())

    spi.flush()

    read_buf = slave.exchange(out=write_buf.tobytes(), readlen=4, start=True, stop=False, duplex=True)
    
    time.sleep(0.2)

    for i in range(0, 80, 4):
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+1] = int.from_bytes(read_buf, byteorder = 'big', signed = False) 
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+2] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+3] = int.from_bytes(read_buf, byteorder = 'big', signed = False)

    spi.flush()

    for i in range(0, 80, 8):
        x0 = float(local[i] + (local[i+4]*256))*(3.3/4096)
        x1 = float(local[i+1] + (local[i+5]*256))*(3.3/4096)
        x2 = float(local[i+2] + (local[i+6]*256))*(3.3/4096)
        x3 = float(local[i+3] + (local[i+7]*256))*(3.3/4096)

        mcutemp0.write("%f \t" % x0)
        mcutemp1.write("%f \t" % x1)
        mcutemp2.write("%f \t" % x2)
        mcutemp3.write("%f \t" % x3)

        mcutemp0.flush(), mcutemp1.flush(), mcutemp2.flush(), mcutemp3.flush()

    mcutemp0.write("\n"), mcutemp1.write("\n"), mcutemp2.write("\n"), mcutemp3.write("\n")
    mcutemp0.flush(), mcutemp1.flush(), mcutemp2.flush(), mcutemp3.flush()


# VREF MCU operation.
def vref():
    local = np.zeros(20*4)

    write_buf = np.array(np.ones(1)*5, dtype='ubyte')
    pp.pprint(write_buf.tobytes())

    spi.flush()

    read_buf = slave.exchange(out=write_buf.tobytes(), readlen=4, start=True, stop=False, duplex=True)
    
    time.sleep(0.2)

    for i in range(0, 80, 4):
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+1] = int.from_bytes(read_buf, byteorder = 'big', signed = False) 
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+2] = int.from_bytes(read_buf, byteorder = 'big', signed = False)
        read_buf = slave.exchange([], readlen=1, start=False, stop=False, duplex=True)
        local[i+3] = int.from_bytes(read_buf, byteorder = 'big', signed = False)

    for i in range(0, 80, 8):
        x0 = float(local[i] + (local[i+4]*256))*(3.3/4096)
        x1 = float(local[i+1] + (local[i+5]*256))*(3.3/4096)
        x2 = float(local[i+2] + (local[i+6]*256))*(3.3/4096)
        x3 = float(local[i+3] + (local[i+7]*256))*(3.3/4096)

        mcuvref0.write("%f \t" % x0)
        mcuvref1.write("%f \t" % x1)
        mcuvref2.write("%f \t" % x2)
        mcuvref3.write("%f \t" % x3)

        mcuvref0.flush(), mcuvref1.flush(), mcuvref2.flush(), mcuvref3.flush()

    mcuvref0.write("\n"), mcuvref1.write("\n"), mcuvref2.write("\n"), mcuvref3.write("\n")
    mcuvref0.flush(), mcuvref1.flush(), mcuvref2.flush(), mcuvref3.flush()



# Main Program
for i in range(0, acqTotal):
    if txS == 1:
        tx()
    if rfS == 1:
        rf()
    if plS == 1:
        pl()
    if tempS == 1:
        temp()
    if vrefS == 1:
        vref()

    current_time = datetime.datetime.now()
    dt.write("%f \t" % current_time.timestamp())
    dt.write("\n")

    print("\n Current timestamp: ", current_time), print()
    time.sleep(acqDelay)



spi.close(freeze=False)
print ("SPI connection terminated."), print()

# Close Microcontroller files. - Board 0
mcutx0.close()
mcurf0.close()
mcupl0.close()
mcutemp0.close()
mcuvref0.close()
# Close Microcontroller files. - Board 1
mcutx1.close()
mcurf1.close()
mcupl1.close()
mcutemp1.close()
mcuvref1.close()
# Close Microcontroller files. - Board 2
mcutx2.close()
mcurf2.close()
mcupl2.close()
mcutemp2.close()
mcuvref2.close()
# Close Microcontroller files. - Board 3
mcutx3.close()
mcurf3.close()
mcupl3.close()
mcutemp3.close()
mcuvref3.close()
# Close datetime file.
dt.close()

# Program end.